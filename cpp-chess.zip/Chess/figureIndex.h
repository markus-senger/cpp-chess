#pragma once

namespace swe {
	enum class FigureIndex : int {
		rook = 0, knight = 1, bishop = 2, queen = 3, king = 4, pawn = 5
	};
}