#include <SFML/Graphics.hpp>
#include "chessGame.h"

int main() {
	swe::ChessGame();
}