# cpp-chess
[NOT FINISHED YET] A small implementation of a chess game using C++, SFML and the chess engine "Stockfish 16" (Exercise for university)

![image](https://github.com/markus-senger/cpp-chess/assets/77236323/7215280b-a715-4284-8ea9-f5607b7e02b9)

![image](https://github.com/markus-senger/cpp-chess/assets/77236323/35ba0755-123d-47d6-8501-4956c6cfd660)

![image](https://github.com/markus-senger/cpp-chess/assets/77236323/affe2364-0009-4998-bd4a-a1ef63876ac3)

![image](https://github.com/markus-senger/cpp-chess/assets/77236323/6f7ee6ea-d48a-4c90-911e-cd4142bf6bf4)




